/* marketplace.js — products, search/filter/sort, favourites, sell form */
var categories=["College uniforms & clothing","Textbooks & reference books","Stationery & notebooks","Lab coats & laboratory equipment","Test tubes, slides & lab supplies","BCA / BTech technical books","Engineering tools & project components","BBA / MBA study materials","Law books & references","MBBS & medical resources","BPharma study materials","Calculators & electronics","Competitive exam books","Other academic items"];
var departments=["BCA","BTech","MBBS","BPharma","Law","BBA","MBA"];
var products=[ // demo data: each object is one product
 {id:1,name:"BCA Data Structures in C",cat:categories[5],price:350,cond:"Like New",seller:"Aarav S.",sid:"AX-1001",dept:"BCA",img:"books",desc:"Clean copy, no markings."},
 {id:2,name:"College Uniform Blazer (M)",cat:categories[0],price:900,cond:"Used",seller:"Meera K.",sid:"AX-1002",dept:"BBA",img:"uniforms",desc:"Navy blazer, size medium."},
 {id:3,name:"Medical Lab Coat (L)",cat:categories[3],price:450,cond:"Like New",seller:"Rohan P.",sid:"AX-1003",dept:"MBBS",img:"lab-equipment",desc:"White coat, washed once."},
 {id:4,name:"Pack of 6 Notebooks",cat:categories[2],price:180,cond:"New",seller:"Sneha D.",sid:"AX-1004",dept:"BCA",img:"stationery",desc:"Ruled, 200 pages each."},
 {id:5,name:"Test Tube Set (20 pcs)",cat:categories[4],price:260,cond:"New",seller:"Kabir M.",sid:"AX-1005",dept:"BPharma",img:"lab-equipment",desc:"Glass tubes with rack."},
 {id:6,name:"Indian Constitution Reference",cat:categories[8],price:520,cond:"Used",seller:"Ishita R.",sid:"AX-1006",dept:"Law",img:"books",desc:"Latest sample edition, highlighted."},
 {id:7,name:"Scientific Calculator",cat:categories[11],price:700,cond:"Like New",seller:"Dev A.",sid:"AX-1007",dept:"BTech",img:"stationery",desc:"Works perfectly, cover included."},
 {id:8,name:"Marketing Management Notes",cat:categories[7],price:150,cond:"Used",seller:"Pooja N.",sid:"AX-1008",dept:"MBA",img:"books",desc:"Handwritten, semester 2."},
 {id:9,name:"Anatomy Study Guide",cat:categories[9],price:600,cond:"Like New",seller:"Rohan P.",sid:"AX-1003",dept:"MBBS",img:"books",desc:"Colour diagrams."},
 {id:10,name:"Pharmacology Notes Bundle",cat:categories[10],price:240,cond:"Used",seller:"Kabir M.",sid:"AX-1005",dept:"BPharma",img:"books",desc:"Unit-wise notes."},
 {id:11,name:"Arduino Starter Kit",cat:categories[6],price:1200,cond:"New",seller:"Dev A.",sid:"AX-1007",dept:"BTech",img:"lab-equipment",desc:"Board, sensors and wires."},
 {id:12,name:"Aptitude Practice Book",cat:categories[12],price:300,cond:"Used",seller:"Aarav S.",sid:"AX-1001",dept:"BCA",img:"books",desc:"Good for placement prep."}
];
var userListings=load('listings',[]);   // listings added by the user
var favs=load('favs',[]);               // product ids
var recent=load('recent',[]);
var pendingImage="";                    // preview of the chosen image file

function allProducts(){return products.concat(userListings);}
function fill(sel,first,list){$(sel).innerHTML='<option value="">'+first+'</option>'+list.map(function(x){return '<option>'+esc(x)+'</option>';}).join('');}
function imgOf(p){return p.upload||('assets/images/'+p.img+'.svg');}

function cardHTML(p){ // builds one product card
  var fav=favs.indexOf(p.id)>-1;
  return '<article class="card"><img src="'+imgOf(p)+'" alt="'+esc(p.name)+'"><div class="pad"><h3>'+esc(p.name)+'</h3><div class="price">₹'+p.price+'</div>'+
  '<p><span class="tag">'+esc(p.cond)+'</span> '+esc(p.dept)+'</p><p>'+esc(p.cat)+'</p><p>Seller: '+esc(p.seller)+' ('+esc(p.sid)+')</p>'+
  '<div class="btn-row"><button class="btn small" data-view="'+p.id+'">View Details</button><button class="btn small ghost" data-fav="'+p.id+'">'+(fav?'♥ Saved':'♡ Save')+'</button></div></div></article>';
}
function renderProducts(){ // reads the filter inputs, filters the array, then draws cards
  var q=$('#mSearch').value.toLowerCase(),c=$('#mCat').value,d=$('#mDept').value,k=$('#mCond').value,s=$('#mSort').value;
  var list=allProducts().filter(function(p){
    var text=(p.name+' '+p.desc+' '+p.cat).toLowerCase();
    return (!q||text.indexOf(q)>-1)&&(!c||p.cat===c)&&(!d||p.dept===d)&&(!k||p.cond===k);
  });
  if(s==='asc')list.sort(function(a,b){return a.price-b.price;});
  if(s==='desc')list.sort(function(a,b){return b.price-a.price;});
  $('#productGrid').innerHTML=list.length?list.map(cardHTML).join(''):'<div class="card pad"><h3>No products found</h3><p>Try a different keyword or click “Clear filters”.</p></div>';
  $('#featured').innerHTML=products.slice(0,4).map(cardHTML).join('');
  $('#recent').innerHTML=recent.length?recent.map(function(id){var p=allProducts().filter(function(x){return x.id===id;})[0];return p?cardHTML(p):'';}).join(''):'<p>Products you open will appear here.</p>';
}
function toggleFav(id){var i=favs.indexOf(id);if(i>-1){favs.splice(i,1);toast('Removed from favourites');}else{favs.push(id);toast('Saved to favourites');}save('favs',favs);renderProducts();}

function viewProduct(id){
  var p=allProducts().filter(function(x){return x.id===id;})[0];if(!p)return;
  recent=[id].concat(recent.filter(function(x){return x!==id;})).slice(0,4);save('recent',recent);renderProducts();
  openModal('<img class="big" src="'+imgOf(p)+'" alt=""><h2>'+esc(p.name)+'</h2><p class="price">₹'+p.price+' · '+esc(p.cond)+'</p><p>'+esc(p.desc)+'</p><p>'+esc(p.cat)+' · '+esc(p.dept)+'</p><p>Seller: '+esc(p.seller)+' ('+esc(p.sid)+') — demo profile</p>'+
  '<div class="btn-row"><button class="btn" id="buyBtn">Interested in Buying</button>'+(p.upload||p.id>100?'<button class="btn coral" id="delBtn">Remove my listing</button>':'')+'</div>');
  $('#buyBtn').onclick=function(){openModal('<h2>Request sent (simulated)</h2><p>Your interest in <b>'+esc(p.name)+'</b> was recorded for demo purposes. No message or payment was sent to '+esc(p.seller)+'.</p><p>Meet in a public campus area if this were real.</p>');toast('Request simulated');};
  if($('#delBtn'))$('#delBtn').onclick=function(){if(confirm('Remove this listing?')){userListings=userListings.filter(function(x){return x.id!==id;});save('listings',userListings);closeModal();renderProducts();toast('Listing removed');}};
}

function sellForm(){
  pendingImage="";
  openModal('<h2>Sell an Item</h2><form id="sellForm" novalidate><label>Product name<input id="fName"></label><label>Category<select id="fCat">'+categories.map(function(c){return '<option>'+esc(c)+'</option>';}).join('')+'</select></label>'+
  '<label>Price (₹)<input id="fPrice" type="number" min="1"></label><label>Condition<select id="fCond"><option>New</option><option>Like New</option><option>Used</option></select></label>'+
  '<label>Department<select id="fDept">'+departments.map(function(d){return '<option>'+d+'</option>';}).join('')+'</select></label><label>Short description<textarea id="fDesc" rows="2"></textarea></label>'+
  '<label>Seller name<input id="fSeller"></label><label>Demo student ID (e.g. AX-1234)<input id="fSid"></label><label>Image (optional)<input id="fImg" type="file" accept="image/*"></label><img id="preview" class="big" alt="" hidden>'+
  '<p class="err" id="fErr"></p><button class="btn" type="submit">Add listing</button></form>');
  $('#fImg').onchange=function(){var f=this.files[0];if(!f)return;var r=new FileReader();r.onload=function(){pendingImage=r.result;$('#preview').src=pendingImage;$('#preview').hidden=false;};r.readAsDataURL(f);};
  $('#sellForm').onsubmit=function(e){e.preventDefault();addListing();};
}
function addListing(){ // validate, then push a new object into the array
  var name=$('#fName').value.trim(),price=+$('#fPrice').value,desc=$('#fDesc').value.trim(),seller=$('#fSeller').value.trim(),sid=$('#fSid').value.trim();
  var err='';
  if(name.length<3)err='Enter a product name (3+ characters).';
  else if(!(price>0))err='Enter a price greater than 0.';
  else if(desc.length<5)err='Add a short description.';
  else if(!seller)err='Enter the seller name.';
  else if(!/^AX-\d{4}$/i.test(sid))err='Demo student ID must look like AX-1234.';
  if(err){$('#fErr').textContent=err;toast('Please fix the form',true);return;}
  userListings.push({id:100+Date.now()%100000,name:name,cat:$('#fCat').value,price:price,cond:$('#fCond').value,seller:seller,sid:sid.toUpperCase(),dept:$('#fDept').value,img:'books',desc:desc,upload:pendingImage});
  try{save('listings',userListings);}catch(e){}
  closeModal();renderProducts();toast('Listing added (this browser only)');
}

function initMarketplace(){
  fill('#mCat','All categories',categories);fill('#mDept','All departments',departments);
  ['#mSearch','#mCat','#mDept','#mCond','#mSort'].forEach(function(s){$(s).addEventListener('input',renderProducts);});
  $('#mClear').onclick=function(){$('#mSearch').value='';['#mCat','#mDept','#mCond','#mSort'].forEach(function(s){$(s).value='';});renderProducts();toast('Filters cleared');};
  $('#sellBtn').onclick=sellForm;
  document.addEventListener('click',function(e){ // one listener handles all card buttons
    var v=e.target.closest('[data-view]'),f=e.target.closest('[data-fav]');
    if(v)viewProduct(+v.dataset.view);if(f)toggleFav(+f.dataset.fav);
  });
  renderProducts();
}
