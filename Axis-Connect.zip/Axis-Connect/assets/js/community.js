/* community.js — students, chat, campus map, events, clubs */
var students=[
 {name:"Aarav Sharma",id:"AX-1001",dept:"BCA",type:"Current Student",year:"2nd Year",bio:"Loves C and web design.",av:1},
 {name:"Meera Kapoor",id:"AX-1002",dept:"BBA",type:"Current Student",year:"3rd Year",bio:"Marketing and debate.",av:2},
 {name:"Rohan Patel",id:"AX-1003",dept:"MBBS",type:"Current Student",year:"1st Year",bio:"Anatomy enthusiast.",av:3},
 {name:"Sneha Das",id:"AX-1004",dept:"BTech",type:"Current Student",year:"2nd Year",bio:"Robotics club member.",av:4},
 {name:"Kabir Mehta",id:"AX-1005",dept:"BPharma",type:"Alumni",year:"Alumni 2025",bio:"Now in pharma research.",av:1},
 {name:"Ishita Rao",id:"AX-1006",dept:"Law",type:"Current Student",year:"3rd Year",bio:"Moot court regular.",av:2},
 {name:"Dev Arora",id:"AX-1007",dept:"MBA",type:"Alumni",year:"Alumni 2024",bio:"Startup mentor.",av:3},
 {name:"Pooja Nair",id:"AX-1008",dept:"BCA",type:"Alumni",year:"Alumni 2025",bio:"Junior web developer.",av:4}
];
var clubs=[
 ["Coding & Programming Club","Code together and build projects.","Web, DSA, apps","Fri 4 PM, Lab 2"],
 ["AI & Robotics Club","Build bots and explore AI.","Arduino, ML","Wed 3 PM, Lab 4"],
 ["Cybersecurity Club","Learn safe computing.","Ethical hacking, CTFs","Thu 4 PM, Lab 3"],
 ["Entrepreneurship Club","Turn ideas into startups.","Pitching, business plans","Mon 2 PM, Seminar Hall"],
 ["Debate & Literary Club","Speak, write, argue well.","Debate, poetry","Tue 3 PM, Room 12"],
 ["Cultural & Dance Club","Dance and cultural nights.","Dance, drama","Sat 11 AM, Auditorium"],
 ["Music Club","Jam sessions and concerts.","Vocals, guitar","Wed 5 PM, Activity Area"],
 ["Photography & Media Club","Photos, reels and editing.","Photo, video","Fri 2 PM, Room 5"],
 ["Sports Club","Teams and tournaments.","Cricket, football","Daily 6 AM, Ground"],
 ["Social Service Club","Community drives.","Blood camps, cleanliness","Sun 10 AM, Main Gate"]
];
var events=[
 {id:1,t:"Axis Hackathon (demo)",date:"2026-11-20",time:"9:00 AM",venue:"Computer Lab 1",org:"Coding Club",d:"24-hour team coding contest.",up:true},
 {id:2,t:"Cyber Safety Workshop",date:"2026-11-05",time:"2:00 PM",venue:"Seminar Hall",org:"Cybersecurity Club",d:"Stay safe online.",up:true},
 {id:3,t:"Cultural Fest Meetup",date:"2026-12-02",time:"5:00 PM",venue:"Auditorium",org:"Cultural Club",d:"Performances and food stalls.",up:true},
 {id:4,t:"Alumni Meetup",date:"2026-12-15",time:"11:00 AM",venue:"Canteen Lawn",org:"Alumni Cell",d:"Meet seniors and mentors.",up:true},
 {id:5,t:"Inter-Department Cricket",date:"2026-09-10",time:"8:00 AM",venue:"Sports Ground",org:"Sports Club",d:"Finals were held.",up:false},
 {id:6,t:"Career Guidance Session",date:"2026-08-18",time:"1:00 PM",venue:"Auditorium",org:"Placement Cell",d:"Resume and interview tips.",up:false}
];
var locations=[
 {n:"Main Gate",x:300,y:370,b:"Gate A",d:"Entry point with security desk.",i:"Show your ID card."},
 {n:"Administration Block",x:300,y:290,b:"Block A",d:"Offices and admissions.",i:"Open 9 AM – 4 PM (sample)."},
 {n:"Academic Block 1",x:130,y:200,b:"Block B",d:"BCA/BTech classrooms.",i:"Sample timings."},
 {n:"Computer Labs",x:130,y:100,b:"Block C",d:"Programming and project labs.",i:"Keep bags outside."},
 {n:"Library",x:300,y:150,b:"Block D",d:"Books and quiet study.",i:"Silence please."},
 {n:"Auditorium",x:470,y:100,b:"Block E",d:"Events and seminars.",i:"Seats about 500 (sample)."},
 {n:"Canteen",x:470,y:220,b:"Food Court",d:"Snacks and meals.",i:"Safe public meeting spot."},
 {n:"Medical & Lab Facilities",x:200,y:300,b:"Block F",d:"Labs for MBBS/BPharma.",i:"Lab coat required."},
 {n:"Sports Ground",x:520,y:320,b:"Ground",d:"Cricket and football.",i:"Evenings busy."},
 {n:"Student Activity Area",x:380,y:300,b:"Open area",d:"Clubs and music.",i:"Club stalls here."},
 {n:"Parking Area",x:60,y:340,b:"Lot P",d:"Two- and four-wheelers.",i:"Park in marked bays."}
];
var joined=load('clubs',[]),bookmarks=load('bookmarks',[]),chats=load('chats',null),activeChat=null,showUpcoming=true,zoom=1;

/* ---------- Students ---------- */
function renderStudents(){
  var q=$('#sSearch').value.toLowerCase(),d=$('#sDept').value,t=$('#sType').value;
  var list=students.filter(function(s){return (!q||(s.name+s.id).toLowerCase().indexOf(q)>-1)&&(!d||s.dept===d)&&(!t||s.type===t);});
  $('#studentGrid').innerHTML=list.length?list.map(function(s){return '<article class="card pad"><img src="assets/images/student-avatars/avatar'+s.av+'.svg" alt="" width="60" style="width:60px"><h3>'+esc(s.name)+'</h3><p>'+s.id+' · '+s.dept+'</p><p>'+s.year+'</p><div class="btn-row"><button class="btn small" data-profile="'+s.id+'">Profile</button><button class="btn small coral" data-chat="'+s.id+'">Open Chat</button></div></article>';}).join(''):'<div class="card pad">No students match. Clear the search.</div>';
}
function copyText(txt){
  if(navigator.clipboard&&window.isSecureContext){navigator.clipboard.writeText(txt).then(function(){toast('ID copied');},function(){fallbackCopy(txt);});}else fallbackCopy(txt);
}
function fallbackCopy(txt){var a=document.createElement('textarea');a.value=txt;document.body.appendChild(a);a.select();var ok=false;try{ok=document.execCommand('copy');}catch(e){}document.body.removeChild(a);toast(ok?'ID copied':'Copy failed — select the ID manually',!ok);}
function findStudent(id){return students.filter(function(s){return s.id===id;})[0];}

/* ---------- Chat ---------- */
function now(){return new Date().toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'});}
function initChats(){
  if(!chats){chats={"AX-1002":[{me:false,t:"Hi! Is the blazer still available?",time:"10:02 AM"}],"AX-1004":[{me:false,t:"Coming to robotics club on Wednesday?",time:"09:15 AM"}]};save('chats',chats);}
}
function renderConvs(){
  var q=$('#cSearch').value.toLowerCase();
  var ids=Object.keys(chats).filter(function(id){return findStudent(id).name.toLowerCase().indexOf(q)>-1;});
  $('#convList').innerHTML=ids.length?ids.map(function(id){var s=findStudent(id),m=chats[id];return '<div class="conv'+(id===activeChat?' active':'')+'" data-conv="'+id+'" tabindex="0"><img src="assets/images/student-avatars/avatar'+s.av+'.svg" alt=""><div><b>'+esc(s.name)+'</b><br><small>'+(m.length?esc(m[m.length-1].t.slice(0,24)):'No messages')+'</small></div></div>';}).join(''):'<p>No chats found.</p>';
}
function openChat(id){
  if(!chats[id]){chats[id]=[];save('chats',chats);}
  activeChat=id;showPage('chat');renderConvs();$('#chatTitle').textContent=findStudent(id).name;
  $('#msgs').innerHTML=chats[id].length?chats[id].map(function(m){return '<div class="bubble '+(m.me?'me':'them')+'">'+esc(m.t)+'<small>'+m.time+'</small></div>';}).join(''):'<p>Say hello! (demo only)</p>';
  $('#msgs').scrollTop=99999;
}
function sendMsg(){
  var v=$('#msgInput').value.trim();
  if(!activeChat){toast('Choose a conversation first',true);return;}
  if(!v){toast('Type a message first',true);return;}
  chats[activeChat].push({me:true,t:v,time:now()});save('chats',chats);$('#msgInput').value='';openChat(activeChat);
}
function newChatModal(){
  openModal('<h2>New chat</h2><p>Pick a demo student:</p>'+students.map(function(s){return '<button class="loc" data-chat="'+s.id+'">'+esc(s.name)+' ('+s.dept+')</button>';}).join(''));
}

/* ---------- Campus map ---------- */
function drawMap(){
  var svg='<rect width="600" height="400" fill="#BBF7D0"/><rect x="0" y="255" width="600" height="25" fill="#CBD5E1"/><rect x="285" y="255" width="30" height="145" fill="#CBD5E1"/>'+
  '<rect x="90" y="70" width="120" height="160" rx="10" fill="#C7D2FE"/><rect x="250" y="110" width="100" height="70" rx="10" fill="#DDD6FE"/><rect x="430" y="60" width="90" height="70" rx="10" fill="#FDE68A"/><rect x="480" y="280" width="100" height="90" rx="10" fill="#86EFAC"/>';
  var q=$('#lSearch').value.toLowerCase();
  locations.forEach(function(l,i){svg+='<g class="marker" tabindex="0" role="button" data-loc="'+i+'" aria-label="'+l.n+'"><circle cx="'+l.x+'" cy="'+l.y+'" r="13"/><text x="'+l.x+'" y="'+(l.y-18)+'" text-anchor="middle" font-size="11" fill="#1E1B4B">'+l.n+'</text></g>';});
  $('#mapSvg').innerHTML=svg;
  $('#locList').innerHTML=locations.map(function(l,i){return l.n.toLowerCase().indexOf(q)>-1?'<button class="loc" data-loc="'+i+'">'+l.n+'</button>':'';}).join('')||'<p>No locations found.</p>';
}
function selectLoc(i){ // highlight marker + list item, show details
  var l=locations[i];
  document.querySelectorAll('[data-loc]').forEach(function(e){e.classList.toggle('active',+e.dataset.loc===i);});
  $('#locInfo').innerHTML='<h3>'+l.n+'</h3><p><b>'+l.b+'</b></p><p>'+l.d+'</p><p>Info: '+l.i+'</p><small>Sample layout — not factual.</small>';
}
function setZoom(z){zoom=Math.max(1,Math.min(2.5,z));$('#mapSvg').style.transform='scale('+zoom+')';}

/* ---------- Events ---------- */
function renderEvents(){
  var q=$('#eSearch').value.toLowerCase();
  var list=events.filter(function(e){return e.up===showUpcoming&&(e.t+e.org).toLowerCase().indexOf(q)>-1;});
  $('#eventGrid').innerHTML=list.length?list.map(function(e){var bm=bookmarks.indexOf(e.id)>-1;return '<article class="card"><img src="assets/images/events/event.svg" alt=""><div class="pad"><h3>'+e.t+'</h3><p>'+e.date+' · '+e.time+'</p><p>'+e.venue+' · '+e.org+'</p><p>'+e.d+'</p><div class="btn-row"><button class="btn small" data-ev="'+e.id+'">Register Interest</button><button class="btn small ghost" data-bm="'+e.id+'">'+(bm?'★ Bookmarked':'☆ Bookmark')+'</button></div></div></article>';}).join(''):'<div class="card pad">No events found.</div>';
}

/* ---------- Clubs ---------- */
function renderClubs(){
  $('#joinCount').textContent=joined.length;
  $('#clubGrid').innerHTML=clubs.map(function(c,i){var j=joined.indexOf(i)>-1;return '<article class="card"><div class="pad"><img src="assets/images/clubs/club.svg" alt="" style="width:50px"><h3>'+c[0]+'</h3><p>'+c[1]+'</p><p>Interests: '+c[2]+'</p><p>Meets: '+c[3]+'</p><p>Coordinator: Dr. Sample Faculty (fictional)</p><button class="btn small'+(j?' coral':'')+'" data-club="'+i+'">'+(j?'Joined ✓':'Join Club')+'</button></div></article>';}).join('');
}
function toggleClub(i){
  var k=joined.indexOf(i);
  if(k>-1){if(!confirm('Leave '+clubs[i][0]+'?'))return;joined.splice(k,1);toast('You left the club');}
  else{joined.push(i);toast('Joined '+clubs[i][0]+' (simulated)');}
  save('clubs',joined);renderClubs();
}

function initCommunity(){
  fill('#sDept','All departments',departments);initChats();
  ['#sSearch','#sDept','#sType'].forEach(function(s){$(s).addEventListener('input',renderStudents);});
  $('#cSearch').addEventListener('input',renderConvs);$('#newChat').onclick=newChatModal;
  $('#sendBtn').onclick=sendMsg;$('#msgInput').addEventListener('keydown',function(e){if(e.key==='Enter')sendMsg();});
  $('#clearChat').onclick=function(){if(!activeChat){toast('Choose a conversation first',true);return;}if(confirm('Clear this conversation?')){chats[activeChat]=[];save('chats',chats);openChat(activeChat);toast('Chat cleared');}};
  $('#lSearch').addEventListener('input',drawMap);
  $('#zin').onclick=function(){setZoom(zoom+.4);};$('#zout').onclick=function(){setZoom(zoom-.4);};$('#zreset').onclick=function(){setZoom(1);};
  $('#eSearch').addEventListener('input',renderEvents);
  $('#tabUp').onclick=function(){showUpcoming=true;renderEvents();};$('#tabPast').onclick=function(){showUpcoming=false;renderEvents();};
  document.addEventListener('click',function(e){ // event delegation for all dynamic buttons
    var t=e.target.closest('[data-profile],[data-chat],[data-conv],[data-loc],[data-ev],[data-bm],[data-club]');if(!t)return;
    var d=t.dataset;
    if(d.profile){var s=findStudent(d.profile);openModal('<img src="assets/images/student-avatars/avatar'+s.av+'.svg" alt="" style="width:70px"><h2>'+esc(s.name)+'</h2><p>'+s.id+' · '+s.dept+' · '+s.year+'</p><p>'+esc(s.bio)+'</p><p class="notice">Sample profile — identity is not verified.</p><button class="btn" id="cp">Copy ID</button>');$('#cp').onclick=function(){copyText(s.id);};}
    else if(d.chat){closeModal();openChat(d.chat);}
    else if(d.conv){openChat(d.conv);}
    else if(d.loc!==undefined){selectLoc(+d.loc);}
    else if(d.ev){var ev=events.filter(function(x){return x.id===+d.ev;})[0];openModal('<h2>'+ev.t+'</h2><p>'+ev.date+' · '+ev.time+' · '+ev.venue+'</p><p>'+ev.d+'</p><p class="notice">Registration is simulated; nothing is sent to the college.</p><button class="btn" id="reg">Confirm interest</button>');$('#reg').onclick=function(){closeModal();toast(ev.up?'Interest registered (simulated)':'This event has ended',!ev.up);};}
    else if(d.bm){var b=+d.bm,k=bookmarks.indexOf(b);if(k>-1)bookmarks.splice(k,1);else bookmarks.push(b);save('bookmarks',bookmarks);renderEvents();toast(k>-1?'Bookmark removed':'Event bookmarked');}
    else if(d.club){toggleClub(+d.club);}
  });
  renderStudents();renderConvs();drawMap();renderEvents();renderClubs();
}
