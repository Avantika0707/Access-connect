/* app.js — shared helpers: page switching, modal, toast, storage, theme, counters */
function $(s){return document.querySelector(s);}
function esc(t){var d=document.createElement('div');d.textContent=t;return d.innerHTML;} // stops user text becoming HTML
function save(k,v){try{localStorage.setItem('axis_'+k,JSON.stringify(v));}catch(e){}}
function load(k,def){try{var v=localStorage.getItem('axis_'+k);return v?JSON.parse(v):def;}catch(e){return def;}}

var toastTimer;
function toast(msg,isError){ // small message at the bottom of the screen
  var t=$('#toast');t.textContent=msg;t.className='toast show'+(isError?' error':'');
  clearTimeout(toastTimer);toastTimer=setTimeout(function(){t.className='toast';},2500);
}
function openModal(html){$('#modalBody').innerHTML=html;$('#modalBg').hidden=false;}
function closeModal(){$('#modalBg').hidden=true;}

function showPage(name){ // show one section, hide the rest
  if(!$('#page-'+name)) name='home';
  document.querySelectorAll('.page').forEach(function(p){p.classList.toggle('show',p.id==='page-'+name);});
  document.querySelectorAll('nav a').forEach(function(a){a.classList.toggle('active',a.dataset.page===name);});
  $('#nav').classList.remove('open');window.scrollTo(0,0);
  if(history.replaceState){try{history.replaceState(null,'','#'+name);}catch(e){}}
}

function animateCounters(){ // counts up from 0 to data-count
  document.querySelectorAll('[data-count]').forEach(function(el){
    var end=+el.dataset.count,n=0;
    var timer=setInterval(function(){n++;el.textContent=n;if(n>=end)clearInterval(timer);},80);
  });
}

function initAll(){
  document.querySelectorAll('[data-page]').forEach(function(a){a.addEventListener('click',function(e){e.preventDefault();showPage(a.dataset.page);});});
  document.querySelectorAll('[data-go]').forEach(function(b){b.addEventListener('click',function(){showPage(b.dataset.go);});});
  $('#menuBtn').addEventListener('click',function(){$('#nav').classList.toggle('open');});
  $('#modalClose').addEventListener('click',closeModal);
  $('#modalBg').addEventListener('click',function(e){if(e.target.id==='modalBg')closeModal();});
  document.addEventListener('keydown',function(e){if(e.key==='Escape')closeModal();});
  // dark mode
  if(load('dark',false))document.body.classList.add('dark');
  $('#themeBtn').addEventListener('click',function(){document.body.classList.toggle('dark');save('dark',document.body.classList.contains('dark'));});
  // back to top
  window.addEventListener('scroll',function(){$('#toTop').style.display=window.scrollY>300?'block':'none';});
  $('#toTop').addEventListener('click',function(){window.scrollTo({top:0,behavior:'smooth'});});
  // global search sends the text to the marketplace search box
  function globalSearch(){$('#mSearch').value=$('#globalSearch').value;showPage('market');renderProducts();}
  $('#globalSearchBtn').addEventListener('click',globalSearch);
  $('#globalSearch').addEventListener('keydown',function(e){if(e.key==='Enter')globalSearch();});
  $('#resetAll').addEventListener('click',function(){
    if(confirm('Reset all demo data (listings, favourites, clubs, chats) in this browser?')){
      try{Object.keys(localStorage).forEach(function(k){if(k.indexOf('axis_')===0)localStorage.removeItem(k);});}catch(e){}
      location.reload();
    }
  });
  initMarketplace();initCommunity();
  showPage(location.hash.replace('#','')||'home');
  animateCounters();
}
