AXIS CONNECT — The Student Community of Axis Institute of Higher Education
BCA academic project (frontend only)

OBJECTIVE
A demo student marketplace and community site: marketplace, student directory, chat demo, campus map, events and clubs.

TECHNOLOGIES: HTML5, CSS3, vanilla JavaScript. No backend, no libraries, no internet.

HOW TO START
1. Extract the Axis-Connect folder.
2. Open the folder.
3. Double-click index.html.
4. Use the top navigation to explore.
Any modern browser works (Chrome, Edge, Firefox, Safari).

FOLDER STRUCTURE
index.html            single page; JavaScript switches sections (works from file://)
assets/css/           style.css (design), responsive.css (tablet/mobile)
assets/js/            app.js (helpers, navigation), marketplace.js, community.js
assets/images/        local SVG illustrations, logo, avatars, events, clubs
assets/icons/         local icons
assets/videos, animations   intentionally empty (SVG + CSS used instead)

HOW IT WORKS
- Demo data lives in JavaScript arrays/objects. Functions filter the arrays and draw cards with innerHTML.
- localStorage (key prefix "axis_") keeps listings, favourites, joined clubs, bookmarks, chats and theme in THIS browser only. It is not shared across devices. "Reset all demo data" on the About page clears it.
- Uploaded listing images exist only as a temporary preview in the saved listing; do not treat this as permanent file storage.

LIMITATIONS
- Chat is NOT real-time and reaches no one. Real messaging, accounts and payments need a backend.
- All people, listings, events, faculty and map locations are fictional sample data. The map is not a real campus map.
- Club joining and event registration are simulated.

CHANGING CONTENT
Edit the arrays at the top of marketplace.js (products) and community.js (students, clubs, events, locations). Put new images in assets/images and use the same relative path.
